package demo;

import java.sql.*;

public class AddInvoiceDao {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(JdbcConnection.driverClass);
			con = DriverManager.getConnection(JdbcConnection.connectionUrl, JdbcConnection.username,
					JdbcConnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	public static int addInvoice(AddInvoice i) {
		int status = 0;
		try {
			Connection con = RegistrationDao.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"insert into invoice (cus_name,cus_email,purchase_date,amount,dog_id) values (?,?,?,?,?)");
			ps.setString(1, i.getBuyer());
			ps.setString(2, i.getUsername());
			ps.setString(3, i.getPurchaseDate());
			ps.setString(4, i.getAmount());
			ps.setString(5, i.getDogId());

			status = ps.executeUpdate();

			con.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return status;

	}
}
